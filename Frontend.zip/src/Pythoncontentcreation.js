import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import Compiler from "./Compiler";
import Modal from "./Modal";
import { useNavigate } from "react-router-dom";
import { ClimbingBoxLoader, FadeLoader, PulseLoader } from "react-spinners";
import DefaultTemplate from "./DefaultTemplate";
import SuccessModal from "./SuccessModal";
import EditedSucModal from "./EditedSucModal";
import SQL from "./SQLContentForm"
function Creator() {
  const [explain, setExplain] = useState([]);
  const [showSucModal, setShowSucModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedConcept, setSelectedConcept] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("Easy");
  const [modifiedFileNames, setModifiedFileNames] = useState([]);
  const [reverseFileNamesDict, setReverseFileNamesDict] = useState({});
  const [selectedQuestion, setSelectedQuestion] = useState("");
  const [currentFile, setCurrentFile] = useState("");
  const [testDisabled, setTestDisabled] = useState(false);
  const [concepts, setConcepts] = useState([]);
  const [hints, setHints] = useState([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();
  const [testCases, setTestCases] = useState([]);
  const [keywords, setKeywords] = useState([]);
  const [tags, settags] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [examples, setExamples] = useState([]);
  const [defaultTemplate, setdefaultTemplate] = useState("");
  const [code1, setCode1] = useState("");
  const [code2, setCode2] = useState("");
  const [count, setCount] = useState("");
  const [DisplayFiles, setDisplayFiles] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedTopic, setSelectedTopic] = useState("");
  const [topics, setTopics] = useState([]);
  const [subTopics, setSubTopics] = useState([]);
  const [contentType, setContentType] = useState("default");
  const [mcqQuestion, setMCQQuestion] = useState("");
  const [options, setOptions] = useState({
    option1: "",
    option2: "",
    option3: "",
    option4: "",
  });
  const [url, setUrl] = useState("");
  const [files, setFiles] = useState(null);
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const [correctOption, setCorrectOption] = useState("");
  const [mcqExplanation, setMCQExplanation] = useState("");
  const [selectedSubTopic, setSelectedSubTopic] = useState("");

  const isContentTypeDisabled =
    !selectedSubject || !selectedTopic || !selectedSubTopic;

  const handleExampleValueChange = (exampleIndex, valueIndex, newValue) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Inputs[valueIndex] = newValue;
    setExamples(updatedExamples);
  };

  const handleExampleOutputChange = (exampleIndex, newOutput) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Output = newOutput;
    setExamples(updatedExamples);
  };
  const handleExampleExplanationChange = (exampleIndex, newExplanation) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Explanation = newExplanation;
    setExamples(updatedExamples);
  };

  const addExampleValue = (exampleIndex) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Inputs.push("");
    setExamples(updatedExamples);
  };

  const removeExampleValue = (exampleIndex, valueIndex) => {
    setExamples((prevExamples) => {
      const updatedExamples = [...prevExamples];
      if (updatedExamples[exampleIndex]) {
        const updatedValues = [...updatedExamples[exampleIndex].Inputs];
        updatedValues.splice(valueIndex, 1);
        updatedExamples[exampleIndex] = {
          ...updatedExamples[exampleIndex],
          Inputs: updatedValues,
        };
      }
      return updatedExamples;
    });
  };

  const addExample = () => {
    setExamples([...examples, { Inputs: [""], Output: "", Explanation: "" }]);
  };

  const removeExample = (exampleIndex) => {
    const updatedExamples = examples.filter((_, i) => i !== exampleIndex);
    setExamples(updatedExamples);
  };

  const handleTestCaseValueChange = (testCaseIndex, valueIndex, newValue) => {
    const updatedTestCases = [...testCases];
    updatedTestCases[testCaseIndex].Value[valueIndex] = newValue;
    setTestCases(updatedTestCases);
  };

  const handleTestCaseOutputChange = (testCaseIndex, newOutput) => {
    const updatedTestCases = [...testCases];
    updatedTestCases[testCaseIndex].Output = newOutput;
    setTestCases(updatedTestCases);
  };

  const addTestCaseValue = (testCaseIndex) => {
    const updatedTestCases = [...testCases];
    updatedTestCases[testCaseIndex].Value.push("");
    setTestCases(updatedTestCases);
  };

  const removeTestCaseValue = (testCaseIndex, valueIndex) => {
    setTestCases((prevTestCases) => {
      const updatedTestCases = [...prevTestCases];
      if (updatedTestCases[testCaseIndex]) {
        const updatedValues = [...updatedTestCases[testCaseIndex].Value];
        updatedValues.splice(valueIndex, 1);
        updatedTestCases[testCaseIndex] = {
          ...updatedTestCases[testCaseIndex],
          Value: updatedValues,
        };
      }
      return updatedTestCases;
    });
  };

  const addTestCase = () => {
    setTestCases([...testCases, { Value: [""], Output: "" }]);
  };

  const removeTestCase = (testCaseIndex) => {
    const updatedTestCases = testCases.filter((_, i) => i !== testCaseIndex);
    setTestCases(updatedTestCases);
  };

  const handleKeywordChange = (index, newKeyword) => {
    const updatedKeywords = [...keywords];
    updatedKeywords[index] = newKeyword;
    setKeywords(updatedKeywords);
  };

  const addKeyword = () => {
    setKeywords([...keywords, ""]);
  };
  const handletagChange = (index, newtag) => {
    const updatedtags = [...tags];
    updatedtags[index] = newtag;
    settags(updatedtags);
  };

  const addtag = () => {
    settags([...tags, ""]);
  };
  const handleLogout = () => {
    sessionStorage.clear();
    navigate("/");
  };
  const refreshOutput = () => {
    setRefreshKey((prevKey) => prevKey + 1);
  };

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === "question") {
      setMCQQuestion(value); 
    } else if (name === "explanation") {
      setMCQExplanation(value);
    } else if (name.startsWith("option")) {
      setOptions((prevOptions) => ({
        ...prevOptions,
        [name]: value,
      }));
    } else if (name === "correctOption") {
      setCorrectOption(value); 
    }
  };

  const confirmSave = () => {
    if (contentType === "MCQ") {
      handleMCQSubmit();
    }
    else if (contentType === "Coding") {
      saveJson();
    }
    else if (contentType === "Content") {
      handleContentSubmit()
    }

    setIsModalOpen(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(
        "https://storeholder.blob.core.windows.net/tpdata/Syllabus/LMS%20Content%20Creation%20Syllabus/syllabus.json"
      );
      const blob = await response.blob();
      const reader = new FileReader();

      reader.onload = () => {
        try {
          const jsonData = JSON.parse(reader.result);
          // Set subjects data
          setSubjects(jsonData.subjects);
        } catch (error) {
          console.error("Error parsing JSON:", error);
        }
      };

      reader.readAsText(blob);
    };

    fetchData();
  }, []);

  const handleSubTopicChange = (e) => {
    setSelectedSubTopic(e.target.value);
  };

  const handleSubjectChange = (e) => {
    setSelectedTopic(""); 
    setSelectedSubTopic("");
    const subjectId = e.target.value;
    setSelectedSubject(subjectId);
    const subject = subjects.find(
      (subject) => subject.subject_id === subjectId
    );
    if (subject) {
      setTopics(subject.topics);
      setSelectedTopic("");
      setSubTopics([]); 
    }
  };

  // Update subtopics based on selected topic
  const handleTopicChange = (e) => {
    const topicId = e.target.value;
    setSelectedSubTopic("");
    setSelectedTopic(topicId);
    const topic = topics.find((topic) => topic.topic_id === topicId);
    if (topic) {
      setSubTopics(topic.sub_topics);
    }
  };

  const handleQuestionChange = async (event) => {
    const modifiedFileName = event.target.value;
    const originalFileName = reverseFileNamesDict[modifiedFileName] || "";
    const defaultOptionValue = "defaultSelect";
    setCurrentFile(
      modifiedFileName === "defaultSelect" ? "" : modifiedFileName
    );
    if (modifiedFileName === defaultOptionValue) {
      setTestDisabled(false);
      setSelectedQuestion("");
      setdefaultTemplate("");
      setCode1("");
      setCode2("");
      setTestCases([]);
      setKeywords([]);
      settags([]);
      setExamples([]);
      setExplain([]);
      setHints([]);
      setSelectedDifficulty("");
    } else {
      setTestDisabled(true);
    }
    if (originalFileName) {
      const currentFile = originalFileName;
      setCurrentFile(currentFile);
      try {
        const response = await axios.get(
          `https://pycontentbackend.azurewebsites.net/file_content/${selectedConcept}/${originalFileName}`
        );
        const fileContent = response.data.content;
        const jsonData = JSON.parse(fileContent);
        setSelectedQuestion(jsonData.Qn);
        setdefaultTemplate(jsonData.Template);
        setCode1(jsonData.Ans);
        setCode2(jsonData.FunctionCall);
        setTestCases(
          jsonData.TestCases.slice(1).map((tc) => Object.values(tc)[0])
        );
        setKeywords(jsonData.TestCases[0].Testcase);
        settags(jsonData.Tags || []);
        setExamples(jsonData.Examples.map((exam) => Object.values(exam)[0]));
        setExplain(jsonData.Explanations.map((ex) => Object.values(ex)[0]));
        setHints(jsonData.Hints.map((hint) => Object.values(hint)[0]));
        
        setSelectedDifficulty(jsonData.Level);
      } catch (error) {
        console.error("Error fetching file content:", error);
        setSelectedQuestion("");
        setdefaultTemplate("");
        setCode1("");
        setCode2("");
        setTestCases([]);
        setKeywords([]);
        document.getElementById("quelevel").value = "defaultSelect";
        settags([]);
        setExamples([]);
        setExplain([]);
        setHints([]);
        setSelectedDifficulty("");
      }
    } else {
      setSelectedQuestion("");
      setdefaultTemplate("");
      setCode1("");
      setCode2("");
      setTestCases([]);
      setKeywords([]);
      document.getElementById("quelevel").value = "defaultSelect";
      settags([]);
      setExplain([]);
      setHints([]);
      setSelectedDifficulty("");
    }
  };


  const handleRadioChangeDiff = (event) => {
    setSelectedDifficulty(event.target.value);
  };

  const handleQuestionLevel = (event) => {
    const type = event.target.value[0];
    if (type === "d") {
      setDisplayFiles(modifiedFileNames);
    } else {
      const files = modifiedFileNames.filter((f) => f.charAt(1) === type);
      setDisplayFiles(files);
    }
  };

  const handleContentTypeChange = (e) => {
    setContentType(e.target.value);
  };

  const addExplanation = () => {
    setExplain((prevExplain) => [...prevExplain, ""]);
  };

  const handleExplainChange = (index, value) => {
    setExplain((prevExplain) => {
      const updatedExplain = [...prevExplain];
      updatedExplain[index] = value;
      return updatedExplain;
    });
  };

  const addHint = () => {
    setHints((prevHints) => [...prevHints, ""]);
  };

  const handleHintChange = (index, value) => {
    setHints((prevHints) => {
      const updatedHints = [...prevHints];
      updatedHints[index] = value;
      return updatedHints;
    });
  };
  const saveJson = async () => {
    setIsLoading(true)
    const question = document.querySelector('#que').value;
    const currentDate = new Date();
    const formattedDate = `${currentDate.getDate()}-${currentDate.getMonth() + 1}-${currentDate.getFullYear()} ${currentDate.getHours()}:${currentDate.getMinutes()}:${currentDate.getSeconds()}`;
    const createdBy = sessionStorage.getItem('Email');
    const testCaseObjects = [
      { 'Testcase':keywords },
      ...testCases.map((testCase, index) => ({ [`Testcase`]: testCase }))
    ];
    const explanationObjects = explain.map((explanation, index) => ({
      [`Explanation${index + 1}`]: explanation,
    }));
    const hintObjects = hints.map((hint, index) => ({
      [`Hint${index + 1}`]: hint,
    }));
    const exObjects = examples.map((example, index) => ({
      [`Example`]: example,
    }));
    const concept = selectedConcept;
    const jsonObject = {
      subjects: [
        {
            subject_name: selectedSubject,
            topics: [
                {
                    topic_name: selectedTopic,
                    subtopics: [
                        {
                            subtopic_name: selectedSubTopic,
                            level: selectedDifficulty,
                            type: "mcq",
                            Name: 'Python',
                            QNty: 'PY',
                            CreatedON: currentFile ? undefined : formattedDate,
                            "QnTy" : "code",
                            "MultiSelect" : "0",
                            "QnTe" : "MC9.htm",
                            CreatedBy: createdBy,
                            ConceptID: concept,
                            Tags: tags,
                            Qn: question,
                            Template:defaultTemplate,
                            Examples:exObjects,
                            Ans: code1,
                            FunctionCall:code2,
                            TestCases: testCaseObjects,
                            Explanations: explanationObjects,
                            Hints: hintObjects,
                            currentFile: currentFile === 'defaultSelect' ? '' : currentFile,
                            LastUpdated: formattedDate,
                            "type":"coding",
                            "Query" : "",
                            "Table" :	"",
                        }
                    ]
                }
            ]
        }
    ]
      
    };
    try {
      const response = await axios.post(
          "http://127.0.0.1:8000/Content_creation/course-plan/",
          jsonObject
      );

      if (response.status === 200) {
          setShowSucModal(true);
          setTimeout(() => {
              setShowSucModal(false);
          }, 2000);
          setdefaultTemplate('');
          setCode1('')
          setCode2('');
          setTestCases([]);
          setKeywords([]);
          settags([]);
          setExplain([]);
          setHints([]);
          setModifiedFileNames([]);
          setDisplayFiles([])
          setExamples([])
          setCurrentFile('');
          refreshOutput();
          setSelectedQuestion("");
          setTestDisabled(false);
      }
  } catch (error) {
      console.error("Error:", error);
  }
    // fetch('https://pycontentbackend.azurewebsites.net/api/save-json', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify(jsonObject),
    // })
    //   .then(response => {
    //     if (response.ok) {
    //       if (currentFile=='' | currentFile=='defaultSelect'){
    //         setShowSucModal(true);
    //         setTimeout(() => {
    //           setShowSucModal(false);
    //       }, 2000);
    //       }
    //       else {
    //         setShowEditModal(true);
    //         setTimeout(() => {
    //           setShowEditModal(false);
    //       }, 2000);
    //       }
    //       // setSelectedSection('');
    //       setSelectedQuestion('');
    //       setdefaultTemplate('');
    //       setCode1('')
    //       setCode2('');
    //       setTestCases([]);
    //       setKeywords([]);
    //       settags([]);
    //       setExplain([]);
    //       setHints([]);
    //       setModifiedFileNames([]);
    //       setDisplayFiles([])
    //       setExamples([])

    //       setSelectedDifficulty('');
    //       setCurrentFile('');
    //       refreshOutput();
    //       setTestDisabled(false);
    //       document.getElementById('section').selectedIndex = 0;
    //       document.getElementById("quelevel").value = "defaultSelect";
    //       document.getElementById('concept').selectedIndex = 0;
    //     }
    //   })
    //   .catch(error => {
    //     console.error('Error:', error);
    //   });
    setIsLoading(false)
  };

  const handleUrlChange = (e) => {
    setUrl(e.target.value);
  };

  const handleFilesChange = (e) => {
    setFiles(e.target.files);
  };

  const handleReceiveData = (data) => {
    const sqljson={
      "CreatedOn":data.CreatedOn,
      "CreatedBy":data.CreatedBy,
      "Level":selectedDifficulty,
      "Qn":data.Qn,
      "Query":data.Query,
      "questiontype":data.questiontype,
      "Expl":data.Expl,
      "Hint":data.Hints,
      "Name":data.Name,
      "Testcases":data.Testcases,
      "Table":data.table,
    }
    console.log('rfgergre',sqljson)
  };

  const handleContentSubmit = async () => {
    if (!url ||( files.length === 0 )) {
      setError("URL, files and text are required!");
      return;
    }

    const formData = new FormData();
    formData.append("subject_name",selectedSubject)
    formData.append("topic_name",selectedTopic)
    formData.append("subtopic_name",selectedSubTopic)
    formData.append( "level",selectedDifficulty,   )
    formData.append("type","content")
    formData.append("url", url);
    formData.append("file", files[0]);
    
   try {
    const response = await axios.post(
        "http://127.0.0.1:8000/Content_creation/content/",
        formData
    );

        setShowSucModal(true);
        setTimeout(() => {
            setShowSucModal(false);
        }, 2000);
        setUrl("");
        document.getElementById("files").value = null;
        setFiles(null)
} catch (error) {
    console.error("Error:", error);
}
  };
  const handleMCQSubmit = async () => {
    setIsLoading(true);
 
    const mcqData = {
        subjects: [
            {
                subject_name: selectedSubject,
                topics: [
                    {
                        topic_name: selectedTopic,
                        subtopics: [
                            {
                                subtopic_name: selectedSubTopic,
                                level: selectedDifficulty,
                                type: "mcq",
                                question: mcqQuestion,
                                options: [
                                    options.option1,
                                    options.option2,
                                    options.option3,
                                    options.option4
                                ],
                                correct_answer: options[correctOption],
                                Explanation: mcqExplanation
                            }
                        ]
                    }
                ]
            }
        ]
    };
 
    try {
        const response = await axios.post(
            "http://127.0.0.1:8000/Content_creation/course-plan/",
            mcqData
        );
 
        if (response.status === 200) {
            setShowSucModal(true);
            setTimeout(() => {
                setShowSucModal(false);
            }, 2000);
            setMCQQuestion("");
            setOptions({
                option1: "",
                option2: "",
                option3: "",
                option4: "",
            });
            setCorrectOption("");
            setMCQExplanation("");
        }
    } catch (error) {
        console.error("Error:", error);
    }
 
    setIsLoading(false);
};

  return (
    <>
      <nav
        className="navbar fixed-top mb-5"
        style={{ backgroundColor: "#8fc7d1" }}
      >
        <div className="container-fluid">
          <button
            className="btn btn-dark btn-sm text-white me-2"
            onClick={handleLogout}
          >
            Logout
          </button>
          <h3 className="">Content Creation</h3>
          <span>
            <button
              className="btn btn-success btn-sm text-white ms-2"
              onClick={openModal}
            >
              Save
            </button>
          </span>
        </div>
      </nav>
      <div className="row mt-5 " style={{ width: "100%", overflow: "hidden" }}>
        {isLoading && (
          <div
            className="d-flex justify-content-center align-items-center"
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100vw",
              height: "100vh",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: 9999,
            }}
          >
            <PulseLoader size={10} className="px-2" />
            <FadeLoader />
            <PulseLoader size={10} />
          </div>
        )}
        <div className="col bg-white py-4 ">
          <div className=" ps-3">
            <div>
              <div className="container-fluid">
                <div className="row p-0">
                  <div className="col-6 p-1 ">
                    <label htmlFor="section" className="form-label fs-4">
                      Choose Subject :
                    </label>
                    <select
                      onChange={handleSubjectChange}
                      className="form-select"
                      value={selectedSubject}
                    >
                      <option value="">Select a Subject</option>
                      {subjects.map((subject) => (
                        <option
                          key={subject.subject_id}
                          value={subject.subject_id}
                        >
                          {subject.subject_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-6 p-1">
                    <label htmlFor="concept" className="form-label fs-4">
                      Choose Topic :
                    </label>
                    <select
                      onChange={handleTopicChange}
                      className="form-select"
                      value={selectedTopic}
                      disabled={!selectedSubject} 
                    >
                      <option value="">Select a Topic</option>
                      {topics.map((topic) => (
                        <option key={topic.topic_id} value={topic.topic_id}>
                          {topic.topic_name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="container-fluid">
                <div className="row p-0">
                  <div className="col-6 p-1">
                    <label htmlFor="concept" className="form-label fs-4">
                      Choose Sub Topic :
                    </label>
                    <select
                      disabled={!selectedTopic} 
                      onChange={handleSubTopicChange}
                      className="form-select"
                      value={selectedSubTopic}
                    >
                      <option value="">Select a Subtopic</option>
                      {subTopics.map((subTopic) => (
                        <option
                          key={subTopic.sub_topic_id}
                          value={subTopic.sub_topic_id}
                        >
                          {subTopic.sub_topic_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-6 p-1 ">
                    <label
                      htmlFor="chooseContentType"
                      className="form-label fs-4"
                    >
                      Choose Type :
                    </label>
                    <select
                      className="form-select"
                      id="content_type"
                      value={contentType}
                      onChange={handleContentTypeChange} 
                      disabled={isContentTypeDisabled} 
                    >
                      <option value="default">Select a Type</option>
                      <option value="Content">Content</option>
                      <option value="MCQ">MCQ</option>
                      <option value="Coding">Coding</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className="">
              <div className="container-fluid">
                <div className="row p-0">
                  <div className="col-6 p-1 ">
                    <label htmlFor="chooseQuestion" className="form-label fs-4">
                      Choose Level :
                    </label>
                    <select
                      className="form-select"
                      id="quelevel"
                      onChange={handleRadioChangeDiff}
                    >
                      <option value="Easy">Easy</option>
                      <option value="Medium">Medium</option>
                      <option value="Hard">Hard</option>
                    </select>
                  </div>
                  <div className="col-6 p-1">
                    <label htmlFor="chooseQuestion" className="form-label fs-4">
                      Choose Question :
                    </label>
                    <select
                      className="form-select"
                      id="quechange"
                      onChange={handleQuestionChange}
                    >
                      <option value="defaultSelect">Select</option>
                      {Array.isArray(DisplayFiles) ? (
                        DisplayFiles.map((fileName) => (
                          <option key={fileName} value={fileName}>
                            {fileName}
                          </option>
                        ))
                      ) : (
                        <option value="">No Questions available</option>
                      )}
                    </select>
                  </div>
                </div>
              </div>
            </div>
            

            {contentType === "MCQ" && (
              <div className="container-fluid">
                <form
                className="shadow px-2 py-2 rounded border"
              >
                <div className="mb-3">
                  <label htmlFor="question" className="form-label">
                    Question:
                  </label>
                  <input
                    type="text"
                    id="question"
                    name="question"
                    className="form-control"
                    value={mcqQuestion}
                    onChange={handleInputChange}
                    placeholder="Enter the question"
                    required
                  />
                </div>
 
                <div className="mb-3">
                  <label className="form-label">Options:</label>
                  <div className="row">
                    {["option1", "option2", "option3", "option4"].map(
                      (option, index) => (
                        <div key={index} className="col-lg-6 col-12 mb-2">
                          <input
                            type="text"
                            name={option}
                            className="form-control"
                            value={options[option]}
                            onChange={handleInputChange}
                            placeholder={`Option ${index + 1}`}
                            required
                          />
                        </div>
                      )
                    )}
                  </div>
                </div>
 
                <div className="mb-3">
                  <label htmlFor="correctOption" className="form-label">
                    Correct Option:
                  </label>
                  <select
                    name="correctOption"
                    className="form-select"
                    value={correctOption}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Correct Option</option>
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                    <option value="option4">Option 4</option>
                  </select>
                </div>
 
                <div className="mb-3">
                  <label htmlFor="explanation" className="form-label">
                    Explanation:
                  </label>
                  <textarea
                    id="explanation"
                    name="explanation"
                    className="form-control"
                    value={mcqExplanation}
                    onChange={handleInputChange}
                    placeholder="Provide an explanation for the correct answer"
                    rows="4"
                    required
                  />
                </div>
 
              </form>
              </div>
            )}
            {contentType === "Content" && (
              <div className="container-fluid">
                <h5>File, URL, and Text Upload</h5>
                {error && <div className="alert alert-danger">{error}</div>}
                <form
                 
                  style={{
                    border: "1px solid #ddd",
                    padding: "20px",
                    borderRadius: "5px",
                  }}
                >
                  {/* URL Input Field */}
                  <div className="mb-3">
                    <label htmlFor="url" className="form-label">
                      URL
                    </label>
                    <input
                      type="url"
                      className="form-control"
                      id="url"
                      value={url}
                      onChange={handleUrlChange}
                      placeholder="Enter URL"
                      style={{ width: "100%" }}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="files" className="form-label">
                      Upload Files
                    </label>
                    <input
                      type="file"
                      className="form-control"
                      id="files"
                      onChange={handleFilesChange}
                      accept=".txt, .pdf, .doc, .docx"
                      style={{ width: "100%" }}
                    />
                  </div>
                </form>
              </div>
            )}
            {contentType === "Coding" && (
              <>
              {selectedSubject=="PY01" && (
                <div className="row">
                  <div className="col-lg-6">
                    <div className="mb-4">
                      <h5 className="text-muted">Question:</h5>
                      <textarea
                        id="que"
                        rows="4"
                        placeholder="Enter Question here....."
                        className="form-control"
                        value={selectedQuestion}
                        onChange={(e) => setSelectedQuestion(e.target.value)}
                      ></textarea>
                    </div>
                    <DefaultTemplate
                      key={refreshKey}
                      defaultTemplate={defaultTemplate}
                      setdefaultTemplate={setdefaultTemplate}
                    />
                    <div className="mb-4">
                      <h5 className="text-muted">Examples:</h5>
                      {examples.map((example, exampleIndex) => (
                        <div
                          key={exampleIndex}
                          className="example mt-3 position-relative"
                        >
                          <button
                            className="btn-close bg-danger position-absolute top-0 end-0"
                            aria-label="Close"
                            onClick={() => removeExample(exampleIndex)}
                          />
                          <div className="form-group">
                            <p>
                              Enter Example {exampleIndex + 1} values, output,
                              and explanation:
                            </p>
                            <label>Values:</label>
                            {example.Inputs.map((value, valueIndex) => (
                              <div
                                key={valueIndex}
                                className="mb-2 position-relative"
                              >
                                <input
                                  type="text"
                                  className="form-control"
                                  value={value}
                                  onChange={(e) =>
                                    handleExampleValueChange(
                                      exampleIndex,
                                      valueIndex,
                                      e.target.value
                                    )
                                  }
                                  placeholder={`Enter value ${valueIndex + 1}`}
                                />
                                {example.Inputs.length > 1 && (
                                  <button
                                    className="btn-close position-absolute top-0 end-0"
                                    aria-label="Close"
                                    onClick={() =>
                                      removeExampleValue(
                                        exampleIndex,
                                        valueIndex
                                      )
                                    }
                                  />
                                )}
                              </div>
                            ))}
                            <button
                              className="btn text-light btn-sm mt-1"
                              style={{ backgroundColor: "#377383" }}
                              onClick={() => addExampleValue(exampleIndex)}
                            >
                              Add Value
                            </button>
                          </div>
                          <div className="form-group">
                            <label>Output:</label>
                            <textarea
                              rows="1"
                              className="form-control"
                              value={example.Output}
                              onChange={(e) =>
                                handleExampleOutputChange(
                                  exampleIndex,
                                  e.target.value
                                )
                              }
                              placeholder="Enter output"
                            />
                          </div>
                          <div className="form-group">
                            <label>Explanation:</label>
                            <textarea
                              rows="2"
                              className="form-control"
                              value={example.Explanation}
                              onChange={(e) =>
                                handleExampleExplanationChange(
                                  exampleIndex,
                                  e.target.value
                                )
                              }
                              placeholder="Enter explanation"
                            />
                          </div>
                        </div>
                      ))}
                      <button
                        className="btn text-light btn-sm mt-1"
                        style={{ backgroundColor: "#377383" }}
                        onClick={addExample}
                      >
                        Add Example
                      </button>
                    </div>
                    <div className="mb-4">
                      <h5 className="text-muted">Keywords:</h5>
                      {keywords.map((keyword, index) => (
                        <div key={index} className="mb-3 position-relative">
                          <div className="form-group">
                            <label htmlFor={`keyword${index}`}>
                              Keyword {index + 1}:
                            </label>
                            <input
                              type="text"
                              id={`keyword${index}`}
                              className="form-control mb-2"
                              value={keyword}
                              onChange={(e) =>
                                handleKeywordChange(index, e.target.value)
                              }
                              placeholder="Enter keyword"
                            />
                            <button
                              className="btn-close position-absolute top-0 end-0"
                              aria-label="Close"
                              onClick={() => {
                                setKeywords((prevKeywords) =>
                                  prevKeywords.filter((_, i) => i !== index)
                                );
                              }}
                            />
                          </div>
                        </div>
                      ))}
                      <button
                        className="btn text-light btn-sm mt-1"
                        style={{ backgroundColor: "#377383" }}
                        onClick={addKeyword}
                      >
                        Add Keyword
                      </button>
                    </div>
                    
                    <div className="mb-4">
                      <h5 className="text-muted">Explanation:</h5>
                      {explain.map((explanation, index) => (
                        <div key={index} className="mb-3 position-relative">
                          <div className="form-group">
                            <label htmlFor={`explanation${index}`}>
                              Explanation {index + 1}:
                            </label>
                            <textarea
                              rows="2"
                              className="form-control mb-2"
                              value={explanation}
                              onChange={(e) =>
                                handleExplainChange(index, e.target.value)
                              }
                              placeholder="Enter explanation"
                            />
                            <button
                              className="btn-close position-absolute top-0 mt-1 end-0"
                              aria-label="Close"
                              onClick={() => {
                                setExplain((prevExplain) =>
                                  prevExplain.filter((_, i) => i !== index)
                                );
                              }}
                            />
                          </div>
                        </div>
                      ))}
                      <button
                        className="btn text-light mt-1 btn-sm"
                        style={{ backgroundColor: "#377383" }}
                        onClick={addExplanation}
                      >
                        Add Explanation
                      </button>
                    </div>
                    <div className="mb-4">
                      <h5 className="text-muted">Hints:</h5>
                      {hints.map((hint, index) => (
                        <div key={index} className="mb-3 position-relative">
                          <div className="form-group">
                            <label htmlFor={`hint${index}`}>
                              Hint {index + 1}:
                            </label>
                            <input
                              type="text"
                              id={`hint${index}`}
                              className="form-control mb-2"
                              value={hint}
                              onChange={(e) =>
                                handleHintChange(index, e.target.value)
                              }
                              placeholder="Enter Hint"
                            />
                            <button
                              className="btn-close position-absolute top-0 end-0"
                              aria-label="Close"
                              onClick={() => {
                                setHints((prevHints) =>
                                  prevHints.filter((_, i) => i !== index)
                                );
                              }}
                            />
                          </div>
                        </div>
                      ))}
                      <button
                        className="btn text-light btn-sm mt-1"
                        style={{ backgroundColor: "#377383" }}
                        onClick={addHint}
                      >
                        Add Hint
                      </button>
                    </div>
                  </div>
                  <div className="col-lg-6">
                    <div className="">
                      <Compiler
                        key={refreshKey}
                        code1={code1}
                        setCode1={setCode1}
                        code2={code2}
                        setCode2={setCode2}
                      />
                      <div className="mb-4">
                        <h5 className="text-muted">Enter Tags :</h5>
                        {tags.map((tag, index) => (
                          <div key={index} className="mb-3 position-relative">
                            <div className="form-group">
                              <label htmlFor={`tag${index}`}>
                                Tag {index + 1}:
                              </label>
                              <input
                                type="text"
                                id={`tag${index}`}
                                className="form-control mb-2"
                                value={tag}
                                onChange={(e) =>
                                  handletagChange(index, e.target.value)
                                }
                                placeholder="Enter tag"
                              />
                              <button
                                className="btn-close position-absolute top-0 end-0"
                                aria-label="Close"
                                onClick={() => {
                                  settags((prevtags) =>
                                    prevtags.filter((_, i) => i !== index)
                                  );
                                }}
                              />
                            </div>
                          </div>
                        ))}
                        <button
                          className="btn text-light btn-sm mt-1"
                          style={{ backgroundColor: "#377383" }}
                          onClick={addtag}
                        >
                          Add tag
                        </button>
                      </div>
                      <div className="mb-4">
                        <h5 className="text-muted">Test cases:</h5>
                        {testCases.map((testCase, testCaseIndex) => (
                          <div
                            key={testCaseIndex}
                            className="test-case mt-3 position-relative"
                          >
                            <button
                              className="btn-close bg-danger position-absolute top-0 end-0"
                              aria-label="Close"
                              onClick={() => removeTestCase(testCaseIndex)}
                            />
                            <div className="form-group">
                              <p>
                                Enter Test case {testCaseIndex + 1} values and
                                output:
                              </p>
                              <label>Values:</label>
                              {testCase.Value.map((value, valueIndex) => (
                                <div
                                  key={valueIndex}
                                  className="mb-2 position-relative"
                                >
                                  <input
                                    type="text"
                                    className="form-control"
                                    value={value}
                                    onChange={(e) =>
                                      handleTestCaseValueChange(
                                        testCaseIndex,
                                        valueIndex,
                                        e.target.value
                                      )
                                    }
                                    placeholder={`Enter value ${
                                      valueIndex + 1
                                    }`}
                                  />
                                  {testCase.Value.length > 1 && (
                                    <button
                                      className="btn-close position-absolute top-0 end-0"
                                      aria-label="Close"
                                      onClick={() =>
                                        removeTestCaseValue(
                                          testCaseIndex,
                                          valueIndex
                                        )
                                      }
                                    />
                                  )}
                                </div>
                              ))}
                              <button
                                className="btn text-light btn-sm mt-1"
                                style={{ backgroundColor: "#377383" }}
                                onClick={() => addTestCaseValue(testCaseIndex)}
                              >
                                Add Value
                              </button>
                            </div>
                            <div className="form-group">
                              <label>Output:</label>
                              <textarea
                                rows="1"
                                className="form-control"
                                value={testCase.Output}
                                onChange={(e) =>
                                  handleTestCaseOutputChange(
                                    testCaseIndex,
                                    e.target.value
                                  )
                                }
                                placeholder="Enter output"
                              />
                            </div>
                          </div>
                        ))}
                        <button
                          className="btn text-light btn-sm mt-1"
                          style={{ backgroundColor: "#377383" }}
                          onClick={addTestCase}
                        >
                          Add Test Case
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                    )}

                    {selectedSubject=="CPP01" && (
                      <>
                      <SQL onDataSend={handleReceiveData} />
                      </>
                    )}
                      
                
              </>
            )}
          </div>
        </div>
        <SuccessModal
                      show={showSucModal}
                      onHide={() => setShowSucModal(false)}
                    />
                    <EditedSucModal
                      show={showEditModal}
                      onHide={() => setShowEditModal(false)}
                    />

        <Modal
                  isOpen={isModalOpen}
                  onClose={closeModal}
                  onConfirm={confirmSave}
                />
      </div>
    </>
  );
}

export default Creator;
