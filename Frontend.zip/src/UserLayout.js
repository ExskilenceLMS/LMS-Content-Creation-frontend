import React from 'react';
import { Outlet } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';

const UserLayout = () => {
  return (
    <ProtectedRoute role="content_creator">
      <Outlet />
    </ProtectedRoute>
  );
};

export default UserLayout;
