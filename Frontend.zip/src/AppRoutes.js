import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './Login';

import SQLContentForm from "./SQLContentForm";
import Pythoncontentcreation from './Pythoncontentcreation';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Pythoncontentcreation />} />
   <Route path="/content-creation" element={<Pythoncontentcreation />} />
    </Routes>
  );
};

export default AppRoutes;
