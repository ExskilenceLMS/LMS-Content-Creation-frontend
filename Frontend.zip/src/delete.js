import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Compiler from './Compiler';
import Modal from './Modal';  
import { useNavigate } from 'react-router-dom';
import { FadeLoader ,PulseLoader  } from 'react-spinners';
import DefaultTemplate from './DefaultTemplate';
import SuccessModal from './SuccessModal';
import EditedSucModal from './EditedSucModal';
function Creator() {
  const [explain, setExplain] = useState([]);
  const [showSucModal, setShowSucModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [sections, setSections] = useState([]);
  const [selectedSection, setSelectedSection] = useState('');
  const [selectedConcept, setSelectedConcept] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [modifiedFileNames, setModifiedFileNames] = useState([]);
  const [reverseFileNamesDict, setReverseFileNamesDict] = useState({});
  const [selectedQuestion, setSelectedQuestion] = useState('');
  const [selectedValue, setSelectedValue] = useState('');
  const [currentFile, setCurrentFile] = useState('');
  const [testDisabled, setTestDisabled] = useState(false);
  const [concepts, setConcepts] = useState([]);
  const [hints, setHints] = useState([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();
  const [testCases, setTestCases] = useState([]);
  const [keywords, setKeywords] = useState([]); 
  const [tags, settags] = useState([]); 
  const [isLoading, setIsLoading] = useState(false);
  const [examples, setExamples] = useState([]);
  const [defaultTemplate,setdefaultTemplate]=useState('');
  const [code1, setCode1] = useState('');
  const [code2, setCode2] = useState('');
  const [count,setCount]= useState('');
 const [DisplayFiles,setDisplayFiles]=useState([]);
  const handleExampleValueChange = (exampleIndex, valueIndex, newValue) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Inputs[valueIndex] = newValue;
    setExamples(updatedExamples);
  };

  const handleExampleOutputChange = (exampleIndex, newOutput) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Output = newOutput;
    setExamples(updatedExamples);
  };
  const handleExampleExplanationChange = (exampleIndex, newExplanation) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Explanation = newExplanation;
    setExamples(updatedExamples);
  };

  const addExampleValue = (exampleIndex) => {
    const updatedExamples = [...examples];
    updatedExamples[exampleIndex].Inputs.push('');
    setExamples(updatedExamples);
  };

  const removeExampleValue = (exampleIndex, valueIndex) => {
    setExamples(prevExamples => {
        const updatedExamples = [...prevExamples];
        if (updatedExamples[exampleIndex]) {
            const updatedValues = [...updatedExamples[exampleIndex].Inputs];
            updatedValues.splice(valueIndex, 1);
            updatedExamples[exampleIndex] = {
                ...updatedExamples[exampleIndex],
                Inputs: updatedValues
            };
        }
        return updatedExamples;
    });
  };

  const addExample = () => {
    setExamples([...examples, { Inputs: [""], Output: "", Explanation: "" }]);
  };

  const removeExample = (exampleIndex) => {
    const updatedExamples = examples.filter((_, i) => i !== exampleIndex);
    setExamples(updatedExamples);
  };

const handleTestCaseValueChange = (testCaseIndex, valueIndex, newValue) => {
  const updatedTestCases = [...testCases];
  updatedTestCases[testCaseIndex].Value[valueIndex] = newValue;
  setTestCases(updatedTestCases);
};

const handleTestCaseOutputChange = (testCaseIndex, newOutput) => {
  const updatedTestCases = [...testCases];
  updatedTestCases[testCaseIndex].Output = newOutput;
  setTestCases(updatedTestCases);
};

const addTestCaseValue = (testCaseIndex) => {
  const updatedTestCases = [...testCases];
  updatedTestCases[testCaseIndex].Value.push('');
  setTestCases(updatedTestCases);
};

const removeTestCaseValue = (testCaseIndex, valueIndex) => {
  setTestCases(prevTestCases => {
    const updatedTestCases = [...prevTestCases];
    if (updatedTestCases[testCaseIndex]) {
      const updatedValues = [...updatedTestCases[testCaseIndex].Value];
      updatedValues.splice(valueIndex, 1);
      updatedTestCases[testCaseIndex] = {
        ...updatedTestCases[testCaseIndex],
        Value: updatedValues
      };
    }
    return updatedTestCases;
  });
};

const addTestCase = () => {
  setTestCases([...testCases, { Value: [""], Output: "" }]);
};

const removeTestCase = (testCaseIndex) => {
  const updatedTestCases = testCases.filter((_, i) => i !== testCaseIndex);
  setTestCases(updatedTestCases);
};

const handleKeywordChange = (index, newKeyword) => {
  const updatedKeywords = [...keywords];
  updatedKeywords[index] = newKeyword;
  setKeywords(updatedKeywords);
};

const addKeyword = () => {
  setKeywords([...keywords, '']); 
}; 
const handletagChange = (index, newtag) => {
  const updatedtags = [...tags];
  updatedtags[index] = newtag;
  settags(updatedtags);
};

const addtag = () => {
  settags([...tags, '']); 
}; 
  const handleLogout = () => {
    sessionStorage.clear();
    navigate('/');
  };
  const refreshOutput = () => {
    setRefreshKey(prevKey => prevKey + 1);  
  };
  
  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const confirmSave = () => {
    saveJson();
    setIsModalOpen(false);
  };
  const getCount = async () => {
    try {
        const response = await fetch('https://pycontentbackend.azurewebsites.net/get_count_cc/Python');
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error);
        }
        const data = await response.json();
        setCount(data.count);
    } catch (err) {
        console.log('Error',err)
    }
};

  useEffect(() => {
    const fetchSections = async () => {
      try {
        getCount()
        const response = await axios.get('https://pycontentbackend.azurewebsites.net/api/get-file/py'); 
        if (response.data && response.data.Sections[0]['Subsections']) {
          setSections(response.data.Sections[0]['Subsections']);
        } else {
          console.error('No sections found in JSON data');
        }
      } catch (error) {
        console.error('Error fetching sections:', error);
      }
    };

    fetchSections();
  }, []);

  useEffect(() => {
   
  
    fetchData();
  }, [selectedConcept]);
  const fetchData = async () => {
    if (!selectedConcept) return;

    try {
      const response = await axios.get(`https://pycontentbackend.azurewebsites.net/files/${selectedConcept}`);
      const files = response.data.files || [];
      
      const modifiedFiles = files.map(file => {
        const firstChar = file.charAt(0);
        const jsonIndex = file.lastIndexOf('.json');
        const lastTwoChars = file.substring(jsonIndex - 2, jsonIndex);
        const level=file.charAt(jsonIndex-4)
       return `${firstChar}${level}${lastTwoChars}`;
      });
      setModifiedFileNames(modifiedFiles);
      setDisplayFiles(modifiedFiles)
      const fileNamesDict = {};
      const reverseFileNamesDict = {};
      files.forEach((file, index) => {
        fileNamesDict[file] = modifiedFiles[index];
        reverseFileNamesDict[modifiedFiles[index]] = file;
      });
      setReverseFileNamesDict(reverseFileNamesDict);
    } catch (error) {
      console.error('Error fetching files:', error);
      setModifiedFileNames([]);
      setDisplayFiles([])
    }
  };
  
  const handleSectionChange = (event) => {
    const selectedSection = event.target.value;
    setSelectedSection(selectedSection);
    setSelectedConcept('');
    setModifiedFileNames([]);
    setSelectedQuestion('');
    setDisplayFiles([])
    setdefaultTemplate('')
    setCode1('')
    setCode2('');
    setTestCases([]); 
    document.getElementById("quelevel").value = "defaultSelect";
    setKeywords([])
    settags([]);
    setExamples([])
    setExplain([]); 
    setSelectedValue(''); 
    setSelectedDifficulty(''); 
    const sectionObject = sections.find(sec => sec.Name === selectedSection);
    if (sectionObject && sectionObject.Chapters) {
      const allConcepts = sectionObject.Chapters.map(chapter => ({
          id: chapter.Concept,
          name: chapter.Name
        }));
        setConcepts(allConcepts);
  }else {
    setConcepts([]);
    }
    setSelectedConcept('');
  };

  const handleConceptChange = async (event) => {
    setSelectedConcept(event.target.value);
    setModifiedFileNames([])
    setTestDisabled(false);
    setSelectedValue(''); 
    setSelectedDifficulty(''); 
    setDisplayFiles([])
    setCurrentFile('');
    setSelectedQuestion('');
    setdefaultTemplate('');
    setCode1('')
    setCode2('');
    setTestCases([]); 
    setKeywords([]);
    settags([]);
    setExamples([])
    setExplain([]); 
    document.getElementById("quelevel").value = "defaultSelect";

    
  };
  
  const handleQuestionChange = async (event) => {
    
    const modifiedFileName = event.target.value;
    const originalFileName = reverseFileNamesDict[modifiedFileName] || '';
    const defaultOptionValue = "defaultSelect"; 
  setCurrentFile(modifiedFileName === 'defaultSelect' ? '' : modifiedFileName);
    if (modifiedFileName === defaultOptionValue) {
      setTestDisabled(false);
      setSelectedQuestion('');
        setdefaultTemplate('');
        setCode1('')
        setCode2('');
        setTestCases([]);
        setKeywords([]);
        settags([]);
        setExamples([])
        setExplain([]);
        setHints([]); 
        setSelectedValue('');
        setSelectedDifficulty('');
    } else {
    setTestDisabled(true);
    }
    if (originalFileName) {
      const currentFile = originalFileName; 
      setCurrentFile(currentFile);
      try {
        const response = await axios.get(`https://pycontentbackend.azurewebsites.net/file_content/${selectedConcept}/${originalFileName}`);
        const fileContent = response.data.content;
        const jsonData = JSON.parse(fileContent);
        setSelectedQuestion(jsonData.Qn);
        setdefaultTemplate(jsonData.Template);
        setCode1(jsonData.Ans);
        setCode2(jsonData.FunctionCall);
        setTestCases(jsonData.TestCases.slice(1).map(tc => Object.values(tc)[0]));
        setKeywords(jsonData.TestCases[0].Testcase)
        settags(jsonData.Tags || [])
        setExamples(jsonData.Examples.map(exam=>Object.values(exam)[0]))
        setExplain(jsonData.Explanations.map(ex => Object.values(ex)[0]));
        setHints(jsonData.Hints.map(hint => Object.values(hint)[0])); 
        setSelectedValue(jsonData.QuestionType);
        setSelectedDifficulty(jsonData.Level);
      } catch (error) {
        console.error('Error fetching file content:', error);
        setSelectedQuestion('');
        setdefaultTemplate('');
        setCode1('')
        setCode2('');
        setTestCases([]);
        setKeywords([]);
        document.getElementById("quelevel").value = "defaultSelect";
        settags([]); 
        setExamples([])
        setExplain([]);
        setHints([]); 
        setSelectedValue('');
        setSelectedDifficulty('');
      }
    } else {
      setSelectedQuestion('');
      setdefaultTemplate('');
      setCode1('')
      setCode2('');
      setTestCases([]);
      setKeywords([]);
      document.getElementById("quelevel").value = "defaultSelect";
      settags([]);
      setExplain([]);
      setHints([]); 
      setSelectedValue('');
      setSelectedDifficulty('');
    }
  };
  
  const handleRadioChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const handleRadioChangeDiff = (event) => {
    setSelectedDifficulty(event.target.value);
    
  };
  
  const handleQuestionLevel=(event)=> {
    const type = event.target.value[0];
    if (type==='d')
    {
      setDisplayFiles(modifiedFileNames)
    }
    else{
      const files = modifiedFileNames.filter(f => f.charAt(1) === type);
      setDisplayFiles(files);
    }
    
  }


  const addExplanation = () => {
    setExplain(prevExplain => [...prevExplain, '']);
  };

  const handleExplainChange = (index, value) => {
    setExplain(prevExplain => {
      const updatedExplain = [...prevExplain];
      updatedExplain[index] = value;
      return updatedExplain;
    });
  }; 
  
  const addHint = () => {
    setHints(prevHints => [...prevHints, ""]);
  };
  
  const deleteFile=async()=>{
    const file=document.getElementById("quechange").value;
    if (file==="defaultSelect"){
      console.log("please select a file ")
    }
    else{
      const originalFileName = reverseFileNamesDict[file] || '';
      try {
        const response = await axios.get(`http://127.0.0.1:8000/delete/${selectedConcept}/${originalFileName}`);
        const fileContent = response.data.content;
        const jsonData = JSON.parse(fileContent);
        
      } catch (error) {
        console.error('Error fetching file content:', error);
        
      }
      setSelectedQuestion('');
        setdefaultTemplate('');
        setCode1('')
        setCode2('');
        setTestCases([]);
        setKeywords([]);
        document.getElementById("quelevel").value = "defaultSelect";
        settags([]); 
        setExamples([])
        setExplain([]);
        setHints([]); 
        setSelectedValue('');
        setSelectedDifficulty('');
    }
  }

  const handleHintChange = (index, value) => {
    setHints(prevHints => {
      const updatedHints = [...prevHints];
      updatedHints[index] = value;
      return updatedHints;
    });
  };
 const saveJson = () => {
  
  setIsLoading(true)
  const question = document.querySelector('#que').value;
  const currentDate = new Date();
  const formattedDate = `${currentDate.getDate()}-${currentDate.getMonth() + 1}-${currentDate.getFullYear()} ${currentDate.getHours()}:${currentDate.getMinutes()}:${currentDate.getSeconds()}`;
  const createdBy = sessionStorage.getItem('Email');
  const testCaseObjects = [
    { 'Testcase':keywords },
    ...testCases.map((testCase, index) => ({ [`Testcase`]: testCase }))
  ];
  const explanationObjects = explain.map((explanation, index) => ({
    [`Explanation${index + 1}`]: explanation,
  }));
  const hintObjects = hints.map((hint, index) => ({
    [`Hint${index + 1}`]: hint,
  }));
  const exObjects = examples.map((example, index) => ({
    [`Example`]: example,
  }));
  const concept = selectedConcept;
  const qtype = selectedValue;
  const level = selectedDifficulty;
  const jsonObject = {
    Name: 'Python',
    QNty: 'PY',
    CreatedON: currentFile ? undefined : formattedDate, 
    "QnTy" : "code",
    "MultiSelect" : "0",
    "QnTe" : "MC9.htm",
    CreatedBy: createdBy,
    ConceptID: concept,
    Level: level,
    Tags: tags,
    QuestionType: qtype,
    Qn: question,
    Template:defaultTemplate,
    Examples:exObjects,
    Ans: code1,
    FunctionCall:code2,
    TestCases: testCaseObjects,
    Explanations: explanationObjects,
    Hints: hintObjects,
    currentFile: currentFile === 'defaultSelect' ? '' : currentFile, 
    LastUpdated: formattedDate, 
    "Query" : "",
    "Table" :	"",
  };
  fetch('https://pycontentbackend.azurewebsites.net/api/save-json', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(jsonObject),
  })
    .then(response => {
      if (response.ok) {
        if (currentFile=='' | currentFile=='defaultSelect'){
          setShowSucModal(true);
          setTimeout(() => {
            setShowSucModal(false);
        }, 2000);
         
        }
        else {
          setShowEditModal(true);
          setTimeout(() => {
            setShowEditModal(false);
        }, 2000);
        }
        getCount()
        // setSelectedSection('');
        setSelectedQuestion('');
        fetchData();
        setdefaultTemplate('');
        setCode1('')
        setCode2('');
        setTestCases([]);
        setKeywords([]);
        settags([]);
        setExplain([]);
        setHints([]);      
        setModifiedFileNames([]);
        setDisplayFiles([])
        setExamples([])
        setSelectedValue('');
        setSelectedDifficulty('');
        setCurrentFile('');
        refreshOutput();  
        setTestDisabled(false);
        document.getElementById('section').selectedIndex = 0;
        document.getElementById("quelevel").value = "defaultSelect";
        document.getElementById('concept').selectedIndex = 0;
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
  setIsLoading(false)

};
 
  return (
    <>
    <nav className="navbar fixed-top mb-5" style={{ backgroundColor: '#8fc7d1' }}>
      <div className="container-fluid">
        <button className="btn btn-dark btn-sm text-white me-2" onClick={handleLogout}>Logout</button>
        <h3 className="">Python Content Creation</h3>
        <span>
        <button className="btn btn-danger btn-sm text-white ms-2" onClick={deleteFile}>Delete</button>
        <button className="btn btn-success btn-sm text-white ms-2" onClick={openModal}>Save</button>
        </span>
        
      </div>
    </nav>
      <div className="row mt-5 " style={{width:'100%',overflow: 'hidden' }}>
      {isLoading && (
        <div className="d-flex justify-content-center align-items-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(255, 255, 255, 0.8)', zIndex: 9999 }}>
          <PulseLoader size={10}  className='px-2' />
          <FadeLoader   />
          <PulseLoader  size={10} />
        </div>
        
      )}
        <div className="col-lg-6 bg-white py-4 ">
          <div className=" px-5">
            <div className="">
            {count !== null && <div className='fs-3 d-flex justify-content-center text-center'>Total Question : {count}</div>}
              <label htmlFor="section" className="form-label fs-4">Choose Section :</label>
              <select name="section" id="section" value={selectedSection} className="form-select" onChange={handleSectionChange}>
                <option value="">Select</option>
                {sections.map((section) => (
                  <option key={section.Name} value={section.Name}>{section.Name}</option>
                ))}
              </select>
            </div>
            <div className="mb-2">
              <label htmlFor="concept" className="form-label fs-4">Choose Concept :</label>
              <select name="concept" id="concept" value={selectedConcept} className="form-select" onChange={handleConceptChange}>
                <option value="">Select</option>
                {concepts.map(concept => (
                  <option key={concept.id} value={concept.id}>{concept.name}</option>
                ))}
              </select>
            </div>
            <div className="">
              <div className='container-fluid'>
                <div className='row p-0'>
                  <div className='col-6 p-1 '>
                  <label htmlFor="chooseQuestion" className="form-label fs-4">Choose Level :</label>
              <select className="form-select" id="quelevel" onChange={handleQuestionLevel}>
                <option value="defaultSelect">All</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>              
              </select>
                  </div>
                  <div className='col-6 p-1'>
                  <label htmlFor="chooseQuestion" className="form-label fs-4">Choose Question :</label>
              <select className="form-select" id="quechange"  onChange={handleQuestionChange}>
                <option value="defaultSelect">Select</option>
                {Array.isArray(DisplayFiles) ?
                  DisplayFiles.map((fileName) => (
                    <option key={fileName} value={fileName}>{fileName}</option>
                  )) : (
                    <option value="">No Questions available</option>
                  )}
              </select>
                  </div>
                </div>
              </div>
             
            </div>
            <div className="mb-2 d-flex my-3">
              <div className="form-check me-3 ">
                <input type="radio" value="Exercise" checked={selectedValue === 'Exercise'} onChange={handleRadioChange} disabled={testDisabled} className="form-check-input" id="Exercise" />
                <label className="form-check-label fs-5" htmlFor="Exercise">Exercise</label>
              </div>
              <div className="form-check">
                <input type="radio" value="Test" checked={selectedValue === 'Test'} disabled={testDisabled} onChange={handleRadioChange} className="form-check-input" id="Test" />
                <label className="form-check-label fs-5" htmlFor="Test">Test</label>
              </div>
            </div>
            <div className="mb-2 d-flex my-3">
              <div className="form-check me-4 ">
                <input type="radio" value="Easy" checked={selectedDifficulty === 'Easy'} disabled={testDisabled} onChange={handleRadioChangeDiff} className="form-check-input" id="Easy" />
                <label className="form-check-label fs-5" htmlFor="Easy">Easy</label>
              </div>
              <div className="form-check me-4">
                <input type="radio" value="Medium" checked={selectedDifficulty === 'Medium'} disabled={testDisabled} onChange={handleRadioChangeDiff} className="form-check-input" id="Medium" />
                <label className="form-check-label fs-5" htmlFor="Medium">Medium</label>
              </div>
              <div className="form-check">
                <input type="radio" value="Hard" checked={selectedDifficulty === 'Hard'} disabled={testDisabled} onChange={handleRadioChangeDiff} className="form-check-input" id="Hard" />
                <label className="form-check-label fs-5" htmlFor="Hard">Hard</label>
              </div>
            </div>
            <div className="mb-4">
              <h5 className="text-muted">Question:</h5>
              <textarea id="que" rows="4" placeholder="Enter Question here....." className="form-control" value={selectedQuestion} onChange={(e) => setSelectedQuestion(e.target.value)}></textarea>
            </div>
            <DefaultTemplate 
        key={refreshKey} 
        defaultTemplate={defaultTemplate}
        setdefaultTemplate={setdefaultTemplate} 
      />
            <div className="mb-4">
      <h5 className="text-muted">Examples:</h5>
      {examples.map((example, exampleIndex) => (
        <div key={exampleIndex} className="example mt-3 position-relative">
          <button
            className="btn-close bg-danger position-absolute top-0 end-0"
            aria-label="Close"
            onClick={() => removeExample(exampleIndex)}
          />
          <div className="form-group">
            <p>Enter Example {exampleIndex + 1} values, output, and explanation:</p>
            <label>Values:</label>
            {example.Inputs.map((value, valueIndex) => (
              <div key={valueIndex} className="mb-2 position-relative">
                <input
                  type="text"
                  className="form-control"
                  value={value}
                  onChange={(e) => handleExampleValueChange(exampleIndex, valueIndex, e.target.value)}
                  placeholder={`Enter value ${valueIndex + 1}`}
                />
                {example.Inputs.length > 1 && (
                  <button
                    className="btn-close position-absolute top-0 end-0"
                    aria-label="Close"
                    onClick={() => removeExampleValue(exampleIndex, valueIndex)}
                  />
                )}
              </div>
            ))}
            <button
              className="btn text-light btn-sm mt-1" style={{backgroundColor:"#377383"}}
              onClick={() => addExampleValue(exampleIndex)}
            >
              Add Value
            </button>
          </div>
          <div className="form-group">
            <label>Output:</label>
            <textarea
              rows="1"
              className="form-control"
              value={example.Output}
              onChange={(e) => handleExampleOutputChange(exampleIndex, e.target.value)}
              placeholder="Enter output"
            />
          </div>
          <div className="form-group">
            <label>Explanation:</label>
            <textarea
              rows="2"
              className="form-control"
              value={example.Explanation}
              onChange={(e) => handleExampleExplanationChange(exampleIndex, e.target.value)}
              placeholder="Enter explanation"
            />
          </div>
        </div>
      ))}
      <button
        className="btn text-light btn-sm mt-1" style={{backgroundColor:"#377383"}}
        onClick={addExample}
      > 
        Add Example
      </button>
    </div>
            <div className="mb-4">
              <h5 className="text-muted">Keywords:</h5>
              {keywords.map((keyword, index) => (
                <div key={index} className="mb-3 position-relative">
                  <div className="form-group">
                    <label htmlFor={`keyword${index}`}>Keyword {index + 1}:</label>
                    <input
                      type="text"
                      id={`keyword${index}`}
                      className="form-control mb-2"
                      value={keyword}
                      onChange={(e) => handleKeywordChange(index, e.target.value)}
                      placeholder="Enter keyword"
                    />
                    <button
                      className="btn-close position-absolute top-0 end-0"
                      aria-label="Close"
                      onClick={() => {
                        setKeywords(prevKeywords => prevKeywords.filter((_, i) => i !== index));
                      }}
                    />
                  </div>
                </div>
              ))}
              <button className="btn text-light btn-sm mt-1" style={{ backgroundColor: "#377383" }} onClick={addKeyword}>Add Keyword</button>
            </div>
            <SuccessModal show={showSucModal} onHide={() => setShowSucModal(false)} />
            <EditedSucModal show={showEditModal} onHide={() => setShowEditModal(false)} />

            <div className="mb-4">
              <h5 className="text-muted">Explanation:</h5>
              {explain.map((explanation, index) => (
                <div key={index} className="mb-3 position-relative">
                    <div className="form-group">
                    <label htmlFor={`explanation${index}`}>Explanation {index + 1}:</label>
                  <textarea
                    rows="2"
                    className="form-control mb-2"
                    value={explanation}
                    onChange={e => handleExplainChange(index, e.target.value)}
                    placeholder="Enter explanation"
                  />
                    <button
                      className="btn-close position-absolute top-0 mt-1 end-0"
                      aria-label="Close"
                      onClick={() => {
                        setExplain(prevExplain => prevExplain.filter((_, i) => i !== index));
                      }}
                    />
                 </div>
                </div>
              ))}
              <button className="btn text-light mt-1 btn-sm" style={{ backgroundColor: "#377383" }} onClick={addExplanation}>Add Explanation</button>
            </div>
            <div className="mb-4">
              <h5 className="text-muted">Hints:</h5>
              {hints.map((hint, index) => (
                <div key={index} className="mb-3 position-relative">
                  <div className="form-group">
                    <label htmlFor={`hint${index}`}>Hint {index + 1}:</label>
                    <input
                      type="text"
                      id={`hint${index}`}
                      className="form-control mb-2"
                      value={hint}
                      onChange={(e) => handleHintChange(index, e.target.value)}
                      placeholder="Enter Hint"
                    />
                    <button
                      className="btn-close position-absolute top-0 end-0"
                      aria-label="Close"
                      onClick={() => {
                        setHints(prevHints => prevHints.filter((_, i) => i !== index));
                      }}
                     />
                  </div>
                </div>
              ))}
              <button className="btn text-light btn-sm mt-1" style={{ backgroundColor: "#377383" }} onClick={addHint}>Add Hint</button>
            </div>
            </div>
          </div>
   
        <div className="col-lg-6 px-2">
          <div className="p-4">
          <Compiler 
        key={refreshKey} 
        code1={code1} 
        setCode1={setCode1} 
        code2={code2} 
        setCode2={setCode2} 
      />
      <div className="mb-4">
              <h5 className="text-muted">Enter Tags :</h5>
              {tags.map((tag, index) => (
                <div key={index} className="mb-3 position-relative">
                  <div className="form-group">
                    <label htmlFor={`tag${index}`}>Tag {index + 1}:</label>
                    <input
                      type="text"
                      id={`tag${index}`}
                      className="form-control mb-2"
                      value={tag}
                      onChange={(e) => handletagChange(index, e.target.value)}
                      placeholder="Enter tag"
                    />
                    <button
                      className="btn-close position-absolute top-0 end-0"
                      aria-label="Close"
                      onClick={() => {
                        settags(prevtags => prevtags.filter((_, i) => i !== index));
                      }}
                    />
                  </div>
                </div>
              ))}
              <button className="btn text-light btn-sm mt-1" style={{ backgroundColor: "#377383" }} onClick={addtag}>Add tag</button>
            </div>
            <div className="mb-4">
            <h5 className="text-muted">Test cases:</h5>
            {testCases.map((testCase, testCaseIndex) => (
        <div key={testCaseIndex} className="test-case mt-3 position-relative">
          <button
            className="btn-close bg-danger position-absolute top-0 end-0"
            aria-label="Close"
            onClick={() => removeTestCase(testCaseIndex)}
          />
          <div className="form-group">
            <p>Enter Test case {testCaseIndex + 1} values and output:</p>
            <label>Values:</label>
            {testCase.Value.map((value, valueIndex) => (
              <div key={valueIndex} className="mb-2 position-relative">
                <input
                  type="text"
                  className="form-control"
                  value={value}
                  onChange={(e) => handleTestCaseValueChange(testCaseIndex, valueIndex, e.target.value)}
                  placeholder={`Enter value ${valueIndex + 1}`}
                />
                {testCase.Value.length > 1 && (
                  <button
                    className="btn-close position-absolute top-0 end-0"
                    aria-label="Close"
                    onClick={() => removeTestCaseValue(testCaseIndex, valueIndex)}
                  />
                )}
              </div>
            ))}
            <button
              className="btn text-light btn-sm mt-1" style={{backgroundColor:"#377383"}}
              onClick={() => addTestCaseValue(testCaseIndex)}
            >
              Add Value
            </button>
          </div>
          <div className="form-group">
            <label>Output:</label>
            <textarea
              rows="1"
              className="form-control"
              value={testCase.Output}
              onChange={(e) => handleTestCaseOutputChange(testCaseIndex, e.target.value)}
              placeholder="Enter output"
            />
          </div>
        </div>
      ))}
      <button
        className="btn text-light btn-sm mt-1" style={{backgroundColor:"#377383"}}
        onClick={addTestCase}
      >
        Add Test Case
      </button>
          </div>
        </div>
      </div>
    <Modal isOpen={isModalOpen} onClose={closeModal} onConfirm={confirmSave} />
    </div>
  </>
  );}

export default Creator;