import React, { useEffect, useState, useRef } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import ApprovalModal from "./ApprovalModal";
import { useNavigate, useLocation } from "react-router-dom";
import SuccessModal from "./SuccessModal";
import EditedSucModal from "./EditedSucModal";
const SQLContentForm = ({ onDataSend }) => {
  const [data, setData] = useState({});
  const [error, setError] = useState(null);
  const [sections, setSections] = useState([]);
  const [selectedSection, setSelectedSection] = useState("");
  const [concepts, setConcepts] = useState([]);
  const [selectedConcept, setSelectedConcept] = useState("");
  const [selectedconceptName, setConceptsName] = useState("");
  const [questions, setQuestions] = useState([]);
  const [fullQuestionNames, setFullQuestionNames] = useState([]);
  const [selectedQuestion, setSelectedQuestion] = useState("");
  const [questionData, setQuestionData] = useState(null);
  const [selectedTables, setSelectedTables] = useState([]);
  const [explanations, setExplanations] = useState([]);
  const [testcases, setTestcases] = useState([]);
  const [tags, setTags] = useState([]);
  const [hints, setHints] = useState([]);
  const [expCounter, setExpCounter] = useState(1);
  const [testCaseCounter, setTestCaseCounter] = useState(1);
  const [hintCounter, setHintCounter] = useState(1);
  const [tagCounter, setTagCounter] = useState(1);
  const [query, setQuery] = useState("");
  const [Rtime, setRtime] = useState();
  const [count, setCount] = useState("");
  const [showSucModal, setShowSucModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [qn, setQn] = useState("");
  const navigate = useNavigate();
  const [table, setTable] = useState("");
  const [isLevelDisabled, setIsLevelDisabled] = useState(false);
  const [isQueryrun, setIsQueryrun] = useState(false);
  const [questiontype, setQuestiontype] = useState("Exercise");
  const [isRadioDisabled, setIsRadioDisabled] = useState(false);
  const formRef = useRef(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [qnlevel, setqnlevel] = useState("easy");

  useEffect(() => {
    fetch("https://pycontentbackend.azurewebsites.net/api/tables-data")
      .then((response) => response.json())
      .then((data) => setData(data))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    getCount();
    async function fetchData() {
      try {
        const response = await axios.get(
          "https://pycontentbackend.azurewebsites.net/api/json_data_view"
        );
        const blobdata = response.data;
        if (blobdata.Sections && blobdata.Sections.length > 0) {
          setSections(blobdata.Sections[0].Subsections);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }
    fetchData();
  }, []);
  const getCount = async () => {
    try {
      const response = await fetch(
        "https://pycontentbackend.azurewebsites.net/get_count_cc/SQL"
      );
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error);
      }
      const data = await response.json();
      setCount(data.count);
    } catch (err) {
      console.log("Error", err);
    }
  };
  const handleSectionChange = (event) => {
    const expectedOpDiv = document.getElementById("expectedop");
    if (expectedOpDiv) {
      expectedOpDiv.innerHTML = "";
    }
    const selectedSectionName = event.target.value;
    setSelectedSection(selectedSectionName);
    setQn("");
    setTable("");
    setQuery("");
    setExplanations([]);
    setTags([]);
    setTestcases([]);
    setHints([]);
    setIsLevelDisabled(false);
    setIsRadioDisabled(false);
    formData.time = "";
    formData.marks = "";
    setQuestions([]);
    setConcepts([]);
    const section = sections.find(
      (section) => section.Name === selectedSectionName
    );
    if (section) {
      setConcepts(section.Chapters);
    } else {
      setConcepts([]);
    }
  };

  const handleconceptforsave = (concept) => {
    axios
      .post(
        "https://pycontentbackend.azurewebsites.net/api/concept/",
        { concept: concept },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
      .then((response) => {
        const levelChar = qnlevel.charAt(0).toUpperCase();
        const formattedQuestions = response.data.files.map((file) => {
          const fullName = file.name.split("/").pop();
          const formattedName = formatQuestionId(fullName);
          return { fullName, formattedName };
        });
        setFullQuestionNames(formattedQuestions);
        setQuestions(formattedQuestions.map((q) => q.formattedName));
      })
      .catch((error) => {
        console.error("Error sending concept:", error);
      });
  };
  const handleConceptChange = (event) => {
    const expectedOpDiv = document.getElementById("expectedop");
    if (expectedOpDiv) {
      expectedOpDiv.innerHTML = "";
    }
    const conceptValue = event.target.value ? event.target.value : event;
    setQuestions([]);
    setFullQuestionNames([]);
    setSelectedQuestion("");
    setQuestionData(null);

    setIsQueryrun(false);
    setSelectedConcept(conceptValue);
    const ConceptName = event.target.options[event.target.selectedIndex].text;
    setQn("");
    setQuery("");
    setExplanations([]);
    setTags([]);
    setTestcases([]);
    setHints([]);
    setIsLevelDisabled(false);
    setConceptsName(ConceptName);
    formData.time = "";
    formData.marks = "";
    setIsRadioDisabled(false);

    axios
      .post(
        "https://pycontentbackend.azurewebsites.net/api/concept/",
        { concept: conceptValue },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
      .then((response) => {
        const levelChar = qnlevel.charAt(0).toUpperCase();
        const formattedQuestions = response.data.files.map((file) => {
          const fullName = file.name.split("/").pop();
          const formattedName = formatQuestionId(fullName);
          return { fullName, fullName };
        });
        setFullQuestionNames(formattedQuestions);
        setQuestions(formattedQuestions.map((q) => q.formattedName));
      })
      .catch((error) => {
        console.error("Error sending concept:", error);
      });
  };
  const formatQuestionId = (id) => {
    if (!id) return "";

    const baseName = id.split(".json")[0];
    const firstCharacter = baseName.charAt(0);
    const lastThreeCharacters = baseName.slice(-2);
    return `${firstCharacter}${lastThreeCharacters}`;
  };

  const handleLevelChange = (event) => {
    const selectedLevel = event.target.value;
    setFormData((prevFormData) => ({
      ...prevFormData,
      level: selectedLevel,
    }));
    const levelChar = selectedLevel.charAt(0).toUpperCase();

    // Filter questions based on the 9th character from the end of the fullName
    const filteredQuestions = fullQuestionNames.filter((q) => {
      const fullName = q.fullName; // Use fullName instead of formattedName
      return fullName.slice(-9, -8) === levelChar;
    });

    const formattedQuestions = filteredQuestions.map((q) => {
      const fullName = q.fullName;
      return {
        fullName,
        formattedName: formatQuestionId(fullName), // Apply your formatting logic here
      };
    });

    // Update the questions state to show the formatted names
    // setQuestions(formattedQuestions.map(q => q.formattedName));
  };

  const handleQuestionChange = async (event) => {
    setQn("");
    setTable("");
    setQuery("");
    setQn("");
    setTable("");
    setQuery("");
    setExplanations([]);
    setTags([]);
    setTestcases([]);
    setHints([]);
    setQuestiontype("Exercise");

    const question = event.target.value;
    setSelectedQuestion(question);
    setIsQueryrun(false);
    const lastFourthLetter =
      question.length >= 9 ? question[question.length - 9] : "";
    const timeChar =
      question.length >= 13 ? question[question.length - 13] : "";
    const markschar =
      question.length >= 12 ? question[question.length - 12] : "";
    const selQuestiontype = question.split("")[0];
    if (selQuestiontype === "Q") {
      setQuestiontype("Exercise");
    } else {
      setQuestiontype("Test");
    }
    const expectedOpDiv = document.getElementById("expectedop");
    if (expectedOpDiv) {
      expectedOpDiv.innerHTML = "";
    }
    setIsLevelDisabled(question ? true : false);
    let level = "";
    switch (lastFourthLetter) {
      case "E":
        level = "easy";
        break;
      case "M":
        level = "medium";
        break;
      case "H":
        level = "hard";
        break;
      default:
        level = "easy";
        break;
    }
    const timeMapping = {
      A: "1",
      B: "2",
      C: "3",
      D: "4",
      E: "5",
      F: "6",
      G: "7",
      H: "8",
      I: "9",
      J: "10",
    };
    const requiredTime = timeMapping[timeChar] || "";
    const requiredmarks = timeMapping[markschar] || "";

    setFormData({
      ...formData,
      level: level,
      time: requiredTime,
      marks: requiredmarks,
    });
    setqnlevel(level);
    setIsLevelDisabled(question ? true : false);
    setIsRadioDisabled(question ? true : false);
    if (question) {
      try {
        const response = await fetch(
          "https://pycontentbackend.azurewebsites.net/api/Question/",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              folder_name: selectedConcept,
              file_name: question,
            }),
          }
        );

        if (!response.ok) {
          const errorText = await response.text();
          console.error("Error response:", errorText);
          setError("Error fetching data");
          setQuestionData(null);
          return;
        }
        const responseData = await response.json();

        if (responseData) {
          setQuestionData(responseData.data);
          setError(null);
        } else {
          setQuestionData(null);
          setError("No data found.");
        }
      } catch (error) {
        console.error("Request failed:", error);
        setError("Request failed");
        setQuestionData(null);
      }
    }
  };

  const openModal = () => {
    setIsModalOpen(true);
  };

  useEffect(() => {
    if (questionData) {
      const initialExplanations = questionData.Expl
        ? questionData.Expl.map((explanation, index) => ({
            id: `textArea-exp${index}`,
            label: `Explanation ${index}`,
            value: explanation.Explanation,
          }))
        : [];

      const initialTags = questionData.Tag
        ? questionData.Tag.map((tag, index) => ({
            id: `textArea-tag${index}`,
            label: `Tag ${index}`,
            value: tag.Tag,
          }))
        : [];
      const initialHints = questionData.Hints
        ? questionData.Hints.map((hint, index) => ({
            id: `textArea-hint${index}`,
            label: `Hint ${index}`,
            value: hint.Hint,
          }))
        : [];

      const initialtestcase = questionData.TestCases
        ? questionData.TestCases.slice(3).map((item, index) => ({
            id: `textArea-testcase${index + 3}`,
            label: `testcase ${index + 3}`,
            value: Array.isArray(item.Testcase)
              ? JSON.stringify(item.Testcase)
              : item.Testcase,
          }))
        : [];

      setExplanations(initialExplanations);
      setHints(initialHints);
      setTags(initialTags);
      setTestcases(initialtestcase);
      setExpCounter(initialExplanations.length);
      setTestCaseCounter(initialtestcase.length);
      setTagCounter(initialTags.length);
      setHintCounter(initialHints.length);
      setQn(questionData.Qn || "");
      setQuery(questionData.Query || "");
      setTable(questionData.Table || "");
    }
  }, [questionData]);

  const handleExplanationChange = (id, event) => {
    setExplanations((prevExplanations) =>
      prevExplanations.map((explanation) =>
        explanation.id === id
          ? { ...explanation, value: event.target.value }
          : explanation
      )
    );
  };
  const handleTestcaseChange = (id, event) => {
    setTestcases((prevExplanations) =>
      prevExplanations.map((testcase) =>
        testcase.id === id
          ? { ...testcase, value: event.target.value }
          : testcase
      )
    );
  };

  const handleTagChange = (id, event) => {
    setTags((prevTags) =>
      prevTags.map((tag) =>
        tag.id === id ? { ...tag, value: event.target.value } : tag
      )
    );
  };

  const handleHintChange = (id, event) => {
    setHints((prevHints) =>
      prevHints.map((hint) =>
        hint.id === id ? { ...hint, value: event.target.value } : hint
      )
    );
  };

  const addExplanation = (value = "") => {
    setExplanations((prevExplanations) => {
      const explanationValue = typeof value === "object" ? "" : String(value);
      const newId = `textArea-exp${expCounter}`;
      const newLabel = `Explanation ${expCounter}`;
      const newExplanation = {
        id: newId,
        label: newLabel,
        value: explanationValue,
      };
      return [...prevExplanations, newExplanation];
    });
    setExpCounter((prevCounter) => prevCounter + 1);
  };

  const deleteExplanation = () => {
    setExplanations((prevExplanations) => {
      if (prevExplanations.length > 0) {
        return prevExplanations.slice(0, -1);
      }
      return prevExplanations;
    });
    setExpCounter((prevCounter) => (prevCounter > 0 ? prevCounter - 1 : 0));
  };
  const addTestcase = (value = "") => {
    setTestcases((prevTestcase) => {
      const TestcaseValue = typeof value === "object" ? "" : String(value);
      const newId = `textArea-testcase${testCaseCounter}`;
      const newLabel = `TestCase ${testCaseCounter}`;
      const newTestcase = { id: newId, label: newLabel, value: TestcaseValue };
      return [...prevTestcase, newTestcase];
    });
    setTestCaseCounter((prevCounter) => prevCounter + 1);
  };

  const DeleteTestcase = () => {
    setTestcases((prevTestcase) => {
      if (prevTestcase.length > 0) {
        return prevTestcase.slice(0, -1);
      }
      return prevTestcase;
    });
    setTestCaseCounter((prevCounter) =>
      prevCounter > 0 ? prevCounter - 1 : 0
    );
  };

  const addTag = (value = "") => {
    setTags((prevTags) => {
      const tagValue = typeof value === "object" ? "" : String(value);
      const newId = `textArea-tag${tagCounter}`;
      const newLabel = `Tag ${tagCounter}`;
      const newTag = { id: newId, label: newLabel, value: tagValue };
      return [...prevTags, newTag];
    });
    setTagCounter((prevCounter) => prevCounter + 1);
  };

  const deleteTag = () => {
    setTags((prevTags) => {
      if (prevTags.length > 0) {
        return prevTags.slice(0, -1);
      }
      return prevTags;
    });
    setTagCounter((prevCounter) => (prevCounter > 0 ? prevCounter - 1 : 0));
  };

  const addHint = (value = "") => {
    setHints((prevHints) => {
      const hintValue = typeof value === "object" ? "" : String(value);
      const newId = `textArea-hint${hintCounter}`;
      const newLabel = `Hint ${hintCounter}`;
      const newHint = { id: newId, label: newLabel, value: hintValue };
      return [...prevHints, newHint];
    });
    setHintCounter((prevCounter) => prevCounter + 1);
  };

  const deleteHint = () => {
    setHints((prevHints) => {
      if (prevHints.length > 0) {
        return prevHints.slice(0, -1);
      }
      return prevHints;
    });
    setHintCounter((prevCounter) => (prevCounter > 0 ? prevCounter - 1 : 0));
  };

  const [formData, setFormData] = useState({
    section: "",
    concept: "",
    content: "",
    time: "",
    marks: "",
    question: "",
    tables: "",
    expectedQuery: "",
    options: "Exercise",
  });
  const handleQtyp = (event) => {
    setFormData({
      ...formData,
      options: event.target.value,
    });
  };
  const selectedOption = formData.options;
  const handleLogout = () => {
    sessionStorage.clear();
    navigate("/");
  };
  const handleRunClick = () => {
    const queryValue = query;
    axios
      .post(
        "https://pycontentbackend.azurewebsites.net/api/run/",
        { query: queryValue },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )

      .then((response) => {
        if (response.status === 200 && response.data.length > 0) {
          renderoptbl(response.data);
        } else {
          renderNoDataMessage();
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        renderNoDataMessage();
      });
    setIsQueryrun(true);
  };

  const renderoptbl = (data) => {
    const headers = Object.keys(data[0]);
    const table = document.createElement("table");
    table.style.width = "100%";
    table.style.borderCollapse = "collapse";

    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    headers.forEach((header) => {
      const th = document.createElement("th");
      th.textContent = header;
      th.style.border = "1px solid black";
      th.style.padding = "8px";
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    const tbody = document.createElement("tbody");
    data.forEach((item) => {
      const row = document.createElement("tr");
      headers.forEach((header) => {
        const td = document.createElement("td");
        td.textContent = item[header] !== undefined ? item[header] : "N/A";
        td.style.border = "1px solid black";
        td.style.padding = "8px";
        row.appendChild(td);
      });
      tbody.appendChild(row);
    });
    table.appendChild(tbody);
    const outputDiv = document.getElementById("expectedop");
    outputDiv.innerHTML = "<h3>Output Table</h3>";
    outputDiv.appendChild(table);
  };
  const renderNoDataMessage = () => {
    const outputDiv = document.getElementById("expectedop");
    outputDiv.innerHTML = "<h3>Output Table</h3><p>No data available</p>";
  };

  const renderTable = (key, tableData) => {
    if (!Array.isArray(tableData) || tableData.length === 0) {
      return null;
    }
    const columns = Object.keys(tableData[0]);
    return (
      <div key={key}>
        <h4>{key}</h4>
        <table className="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col}>{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tableData.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {columns.map((col) => (
                  <td key={col}>{row[col]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    let updatedTables = [...selectedTables];

    if (checked) {
      updatedTables.push(value);
    } else {
      updatedTables = updatedTables.filter((table) => table !== value);
    }
    setSelectedTables(updatedTables);
    setTable(updatedTables.join(", "));
  };

  useEffect(() => {
    const tableArray = table.split(", ").filter(Boolean);
    setSelectedTables(tableArray);
  }, [table]);

  const getFormattedData = () => {
    const textAreas = document.querySelectorAll("textarea");

    const formattedExplanations = Array.from(textAreas)
      .filter((textArea) => textArea.id.startsWith("textArea-exp"))
      .map((textArea) => ({
        Explanation: textArea.value,
      }));

    const formattedTags = Array.from(textAreas)
      .filter((textArea) => textArea.id.startsWith("textArea-tag"))
      .map((textArea) => textArea.value.trim());

    const formattedHints = Array.from(textAreas)
      .filter((textArea) => textArea.id.startsWith("textArea-hint"))
      .map((textArea) => ({
        Hint: textArea.value,
      }));
    const formattedTestcase = Array.from(textAreas)
      .filter((textArea) => textArea.id.startsWith("textArea-testcase"))
      .map((textArea) => ({ Testcase: textArea.value.trim() }));

    return {
      Expl: formattedExplanations,
      Hints: formattedHints,
      Tags: formattedTags,
      Testcase: formattedTestcase,
    };
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const createdBy = sessionStorage.getItem("Email");
    if (!isQueryrun) {
      alert("Please run the query once before saving the content");
      return;
    }

    const formattedData = getFormattedData();

    const dataToSubmit = {
      Questionid: selectedQuestion,
      Name: selectedconceptName,
      selectedConcept: selectedConcept,
      CreatedOn:
        new Date()
          .toISOString()
          .replace("Z", new Date().getTimezoneOffset() <= 0 ? "+" : "-") +
        (new Date().getTimezoneOffset() / 60).toFixed(0).padStart(2, "0") +
        ":" +
        (new Date().getTimezoneOffset() % 60).toString().padStart(2, "0"),
      Level: formData.level,
      Qn: qn,
      Query: query,
      questiontype: questiontype,
      CreatedBy: createdBy,
      table: table,
      Rtime: formData.time,
      Marks: formData.marks,
      Expl: formattedData.Expl,
      Hints: formattedData.Hints,
      Tags: formattedData.Tags,
      Testcase: formattedData.Testcase,
    };

    setFormData(dataToSubmit);
    setIsModalOpen(true);
  };

  const handleConfirm = async () => {
    setIsModalOpen(false);

    if (!formData) {
      console.error("Form data is not available");
      return;
    }

    try {
      onDataSend(formData);
      // const response = await axios.post(
      //   "https://pycontentbackend.azurewebsites.net/api/jsonsaved/",
      //   formData,
      //   {
      //     headers: {
      //       "Content-Type": "application/json",
      //     },
      //   }
      // );

      getCount();

      if (selectedQuestion == "") {
        setShowSucModal(true);
        setTimeout(() => {
          setShowSucModal(false);
        }, 2000);
      } else {
        setShowEditModal(true);
        setTimeout(() => {
          setShowEditModal(false);
        }, 2000);
      }
      handleconceptforsave(selectedConcept);
      setError(null);
      setQuestions([]);
      setFullQuestionNames([]);
      setSelectedQuestion("");
      setQuestionData(null);
      setSelectedTables([]);
      setTable("");
      setExplanations([]);
      setTestcases([]);
      setTags([]);
      setHints([]);
      setExpCounter(1);
      setTestCaseCounter(1);
      setHintCounter(1);
      setTagCounter(1);
      setQuery("");
      setRtime();
      setQn("");
      setIsLevelDisabled(false);
      formData.time = "";
      formData.marks = "";
      setIsRadioDisabled(false);

      setIsLevelDisabled(false);
      setIsQueryrun(false);
      setQuestiontype("Exercise");
      setIsModalOpen(false);
      setqnlevel("easy");
    } catch (error) {
      console.error("Error sending data to backend:", error);
    }
  };

  const handleClose = () => {
    setIsModalOpen(false);
  };
  return (
    <div className="container-fluid p-0">
      <nav className="navbar"></nav>
      <div className="form-container">
        <form onSubmit={handleSubmit} ref={formRef}>
          <div className="row">
            <div className="col-lg-6 mb-2 col-12">
              <div className="row mb-3">
                <div className="col">
                  <label htmlFor="question">Question</label>
                  <textarea
                    id="sqquestion"
                    name="question"
                    className="form-control"
                    value={qn || ""}
                    onChange={(e) => setQn(e.target.value)}
                    required
                  ></textarea>
                </div>
              </div>
              <div className="row mb-3">
                <div className="col">
                  <label htmlFor="question">Table</label>
                  <input
                    id="sqtable"
                    name="table"
                    className="form-control"
                    value={table || ""}
                    onChange={(e) => setTable(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="row mb-3">
                <div className="col">
                  <label>Select table</label>
                  <div
                    className="ctbls"
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      gap: "10px",
                    }}
                  >
                    <div>
                      <input
                        type="checkbox"
                        id="lecturers"
                        name="tables"
                        value="Lecturers"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Lecturers")}
                      />
                      <label htmlFor="lecturers">Lecturers</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="subjects"
                        name="tables"
                        value="Subjects"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Subjects")}
                      />
                      <label htmlFor="subjects">Subjects</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="marks"
                        name="tables"
                        value="Marks"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Marks")}
                      />
                      <label htmlFor="marks">Marks</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="companies"
                        name="tables"
                        value="Companies"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Companies")}
                      />
                      <label htmlFor="companies">Companies</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="branches"
                        name="tables"
                        value="Branches"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Branches")}
                      />
                      <label htmlFor="branches">Branches</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="students"
                        name="tables"
                        value="Students"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Students")}
                      />
                      <label htmlFor="students">Students</label>
                    </div>
                    <div>
                      <input
                        type="checkbox"
                        id="colleges"
                        name="tables"
                        value="Colleges"
                        onChange={handleCheckboxChange}
                        checked={selectedTables.includes("Colleges")}
                      />
                      <label htmlFor="colleges">Colleges</label>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row mb-3">
                <div className="col">
                  <label htmlFor="expectedQuery">Expected Output Query</label>
                  <textarea
                    id="expectedQuery"
                    name="expectedQuery"
                    className="form-control"
                    value={query || ""}
                    onChange={(e) => setQuery(e.target.value)}
                    required
                  ></textarea>
                </div>
              </div>
              <div className="row mb-3">
                <div className="col">
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleRunClick}
                  >
                    Run
                  </button>
                </div>
              </div>
              <div className="row mb -3">
                <div className="col" id="expectedop">
                  <h5>Output Table</h5>
                </div>
              </div>
              <br></br>
              <div id="textAreaContainer" className="mt-3">
                <div className="row">
                  <div className="col">
                    <h5>Tags</h5>
                    {tags.map((tag) => (
                      <div key={tag.id}>
                        <textarea
                          type
                          value={tag.value || ""}
                          id={tag.id}
                          className="form-control"
                          onChange={(e) => handleTagChange(tag.id, e)}
                        />
                        <br></br>
                      </div>
                    ))}

                    <button
                      onClick={addTag}
                      type="button"
                      className="btn btn-secondary btn-sm"
                    >
                      Add
                    </button>
                    <button
                      onClick={deleteTag}
                      type="button"
                      className="btn btn-secondary btn-sm"
                      style={{ marginLeft: "30px" }}
                    >
                      Delete
                    </button>
                  </div>
                  <div className="col">
                    <h5>Hints</h5>
                    {hints.map((hint) => (
                      <div key={hint.id}>
                        <textarea
                          value={hint.value || ""}
                          id={hint.id}
                          className="form-control"
                          onChange={(e) => handleHintChange(hint.id, e)}
                        />
                        <br></br>
                      </div>
                    ))}
                    <button
                      onClick={addHint}
                      type="button"
                      className="btn btn-secondary btn-sm"
                    >
                      Add
                    </button>
                    <button
                      onClick={deleteHint}
                      type="button"
                      className="btn btn-secondary btn-sm"
                      style={{ marginLeft: "30px" }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
                <div className="row mt-4">
                  <div className="col">
                    <h5>Explanations</h5>
                    {explanations.map((explanation) => (
                      <div key={explanation.id}>
                        <textarea
                          type
                          value={explanation.value || ""}
                          id={explanation.id}
                          className="form-control"
                          onChange={(e) =>
                            handleExplanationChange(explanation.id, e)
                          }
                        />
                        <br></br>
                      </div>
                    ))}

                    <button
                      onClick={addExplanation}
                      type="button"
                      className="btn btn-secondary btn-sm"
                    >
                      Add
                    </button>
                    <button
                      onClick={deleteExplanation}
                      type="button"
                      className="btn btn-secondary btn-sm"
                      style={{ marginLeft: "30px" }}
                    >
                      Delete
                    </button>
                  </div>
                  <div className="col">
                    <h5>Testcases</h5>
                    {testcases.map((testcase) => (
                      <div key={testcase.id}>
                        <textarea
                          value={testcase.value || ""}
                          id={testcase.id}
                          className="form-control"
                          onChange={(e) => handleTestcaseChange(testcase.id, e)}
                        />
                        <br></br>
                      </div>
                    ))}

                    <button
                      onClick={addTestcase}
                      type="button"
                      className="btn btn-secondary btn-sm"
                    >
                      Add
                    </button>
                    <button
                      onClick={DeleteTestcase}
                      type="button"
                      className="btn btn-secondary btn-sm"
                      style={{ marginLeft: "30px" }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="col-lg-6 col-12"
              style={{ height: "100%", maxHeight: "900px", overflowY: "auto" }}
            >
              <div className="tables">
                <div>
                  <h5 style={{ textAlign: "center" }}>Tables</h5>
                  {error ? (
                    <p>Error fetching data: {error}</p>
                  ) : Object.keys(data).length ? (
                    Object.keys(data).map((key) => renderTable(key, data[key]))
                  ) : (
                    <p>Loading...</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="row mb-3">
            <div
              className="col text-end"
              style={{
                position: "fixed",
                top: "10px",
                right: "0px",
                zIndex: "9999",
              }}
            >
            <button
              className="btn btn-success btn-sm text-white ms-2"
            >
              Save
            </button>
            </div>
          </div>
        </form>
      </div>

      <ApprovalModal
        isOpen={isModalOpen}
        onClose={handleClose}
        onConfirm={handleConfirm}
      />
    </div>
  );
};
export default SQLContentForm;
