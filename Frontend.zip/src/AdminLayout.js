import React from 'react';
import { Outlet } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';

function AdminLayout() {
  return (
    <div>
      <ProtectedRoute role="admin">
        <Outlet />
      </ProtectedRoute>
    </div>
  );
}

export default AdminLayout;
